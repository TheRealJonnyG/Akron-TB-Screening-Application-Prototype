const express = require('express');
const oracledb = require('oracledb');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const PORT = 3000; 

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('Public'));

//-------------------------------------------------------------------------------------------//
const dbConfig = {
  user: 'ADMIN',
  password: 'WeL0vePureLungs',
  connectString: "C:/Users/Frankie/Documents/Wallet_J5T04Z4GLLFDEXKF 1.zip"
};
//------------------------------------------------------------------------------------------//

app.post('/login', async (req, res) => 
{
  let { username, password } = req.body;
  try 
  {
    const connection = await oracledb.getConnection('C:\Users\Frankie\Downloads\Wallet_J5T04Z4GLLFDEXKF 1.zip');
    const result = await connection.execute(
      `SELECT * FROM students WHERE username = :username AND password = :password`,
      [username, password],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    if (result.rows.length > 0) 
    {
      res.send({ redirect: 'pg2.html' });
    } 
    else
    {
      res.status(401).send('Incorrect username or password');
    }
    await connection.close();
  }
   catch (err) 
  {
    console.error(err);
    res.status(500).send('Connection Error');
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
